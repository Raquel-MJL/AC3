
<!DOCTYPE html>
<html>

	<head>
		<title>Archivos 5 | PHP</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/estilos_archivos5.css">

		<style>
			table, tr, th, td {
				border: 2px solid navy;
			}
			caption{
			font-weight:bold;
			color:navy;
		}
		</style>
		
	</head>
	
	<body>
	
	<h1>Restaurante Carpanta</h1>
	<div id ="contenedor">
		
		
		<div class ="ejercicios">
			<?php
			/* Ejercicio 1. */

				/* Array de platos. */

					$platos = array("Ensalada", "Gazpacho", "Menestra", "Raviolis", "Macarrones", "Merluza a la Vasca", "Entrecot", "Hamburguesa", "Pollo al Ajillo", "Paella");
						
				/* Array de precios generados y asociados aleatoriamete a cada plato. */
					$precios = array();
					for ( $i=0; $i<count($platos); $i++ ) {
						$precio = rand(10,20);
						array_push($precios, $precio);
				}
						
				/* Array asociativo $menu fusionando los arrays $platos y $precios. */
				
					$menu = array_combine($platos, $precios);
						
				/* Menú ordenado alfabéticamente por los nombres de los platos. */
					
					ksort($menu);

				/* Tabla con el menú. */
			
			?>
			<table>
				<caption>Menú del día</caption>
				<tr>
					<th>Plato</th>
					<th>Precio</th>
				</tr>
				<?php
				foreach ( $menu as $plato => $precio ) {
					?>
					<tr>
						<td><?php echo $plato; ?></td>
						<td><?php echo $precio; ?> €</td>
					</tr>
					<?php
				}
				?>
			</table>
			</div>
		<?php
		
		/* Imprimir el menú en un archivo de texto (los platos con sus precios). */
		
			$archivo1 = fopen("menu.txt", "w");
			fwrite($archivo1, "Menú del día" . PHP_EOL . PHP_EOL);
			foreach ($menu as $plato => $precio )
			{
				$linea1 = $plato. " ----- " . $precio. "€" . PHP_EOL;
				fwrite($archivo1, $linea1);
			}
			fclose($archivo1);
		
		/* Ejercicio 2. */

		/* ¿Hay paella en el menú? */

			$buscar = "Paella";
			if (array_key_exists($buscar, $menu) )
			{
				?>
				<div class ="ejercicios">
					<p>Felicidades, hay <?php echo $buscar; ?> en el menú por un precio de <?php echo $menu[$buscar]; ?> €.</p>
				<?php
			} else {
				?>
					<p>Lo sentimos no hay <?php echo $buscar; ?> en el menú.</p>
				</div>
				<?php
			}
		
		/* Sugerir aleatoriamente un plato al usuario indicando su nombre y su precio. */
		
			$recomendado = array_rand($menu, 1);
			$precioRecomendado = $menu[$recomendado];
			?>
			<div class ="ejercicios">
				<p>Hoy recomendamos <?php echo $recomendado; ?> por un precio de <?php echo $precioRecomendado; ?> €.</p>
			</div>
		<?php
		
		/* ¿Cuánto costaría la comida más cara compuesta por dos platos diferentes del menú?, ¿qué platos serían? */
		
		/* Array menú ordenado de más caro a más barato. */
		
			arsort($menu);
		
		/* Obtención de los dos platos más caros al principio del array. */

			$masCaros = array_slice($menu, 0, 2, true);
		
		?>
		
		<p>Nuestra combinación estrella es:</p>
		<ul>
			<?php
				foreach ( $masCaros as $plato => $precio )
				{
					?>
					<li><?php echo $plato; ?></li>
					<?php
				}
				$dosplatos = array_sum($masCaros);
			?>
		</ul>
		
		<p>Por un precio total de <?php echo $dosplatos; ?> €.</p>
		
		<?php
		
		/* Imprimir combinacion de platos mas caros un archivo de texto. */
		
			$archivo2 = fopen("menu2platos.txt", "w");
			fwrite($archivo2, "Menú del día" . PHP_EOL . PHP_EOL);
			foreach ($masCaros as $plato => $precio )
			{
				$linea2 = $plato. " ----- " . $precio. " €" . PHP_EOL;
				fwrite($archivo2, $linea2);
			}
			$total = "Total ----- " .$dosplatos. " €" .PHP_EOL;
			fwrite($archivo2, $total);
			fclose($archivo2);
		
		?>
		
	</div>	
	<h2>¡Bon appétit!</h2>
		
	</body>
	
</html>