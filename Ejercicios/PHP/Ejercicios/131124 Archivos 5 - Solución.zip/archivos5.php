<!DOCTYPE html>
<html lang="es">

	<head>
		
		<title>Catálogo de juegos</title>
		<meta charset="utf-8">
		<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/estilos_archivos5.css">

	</head>
	
	<body>
		<header class ="cabecera">
			<h1>Videojuegos a la venta</h1>
		<header>
		<?php
		
		/* Creación de arrays vacíos. */

			$nombres = array();
			$precios = array();
		
		/* Modificación.*/

			include("archivos5_modificacion.php");
		
		/* Apertura del archivo de títulos para lectura. */

			$archivo = fopen("datos/titulos.txt", "r") or die("Archivo erróneo o no encontrado");
			/* Lectura de las líneas del archivo. */
			while ( !feof($archivo) ) {
				$linea = utf8_encode( fgets($archivo) );
				$codigo = substr($linea, 0, 4);
				$titulo = substr($linea, 5);
				/* Código y título añadidos al array. */
				$nombres[$codigo] = $titulo;
				/* Creación aleatoria del precio. */
				$precios[$codigo] = rand(10,50) - 0.01;
			}
			fclose($archivo);

		/* Creación del array vacío. */
		
			$descripciones = array();
		
		/* Apertura del archivo de descripciones para lectura. */

			$archivo = fopen("datos/descripcion.txt", "r") or die("Archivo erróneo o no encontrado");
			while ( !feof($archivo) ) {
				$linea = utf8_encode( fgets($archivo) );
				$codigo = substr($linea, 0, 4);
				$descripcion = substr($linea, 5);
				/* Código y descripción añadidas al array. */
				$descripciones[$codigo] = $descripcion;
			}
			fclose($archivo);
					
		?>

		<!-- Creación de un contenedor con varias cajas con las fotos, precios y descripciones de los juegos. -->
		<div id="contenedor">
			<?php
			foreach ( $nombres as $codigo => $nombre ) {
				?>
				<div class="juego" id="<?php echo $codigo; ?>">
					<div class="info">
						<img src="<?php echo "imagenes/$codigo.jpg" ?>" />
						<p class="titulos"><?php echo $nombre; ?></p>
						<p class="precio"><?php echo $precios[$codigo]. " €"; ?></p>
						<p class="descripciones"><?php echo $descripciones[$codigo]; ?></p>
					</div>
					
				</div>
				<?php
			}
			?>
		</div>
		
	</body>
	
</html>