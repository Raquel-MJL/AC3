

	<?php

		/* MODIFICACIÓN: */		
					
		/* Apertura del archivo de títulos para escritura. */

			$codigo_buscado ="MOXI";
			$archivo = fopen("datos/titulos.txt", "a+") or die("Archivo erróneo o no encontrado");
			$titulos = fread($archivo,filesize("datos/titulos.txt"));
			$codigo_encontrado = str_contains($titulos,$codigo_buscado); // Búsqueda del código a insertar para no volver a escribir éste y el título si ya existiesen.
			
			if($codigo_encontrado==true)
			{
				fclose($archivo);
			}
			else
			{
				/* Escritura del nuevo código. */
				$nuevo_titulo = PHP_EOL."MOXI-Borderlands";
				fwrite($archivo, $nuevo_titulo) or die("No se pudo escribir en el archivo");
				fclose($archivo);
			}

		/* Apertura del archivo de descripciones para escritura. */

			$archivo = fopen("datos/descripcion.txt", "a+") or die("Archivo erróneo o no encontrado");
			$descrip = fread($archivo,filesize("datos/descripcion.txt"));
			$codigo_encontrado = str_contains($descrip,$codigo_buscado); // Búsqueda del código a insertar para no volver a escribir la descripción si ésta ya existe.
			
			if($codigo_encontrado==true)
			{
				fclose($archivo);
			}
			else
			{
				/* Escritura de la nueva descripción. */
				$nueva_descripcion = PHP_EOL."MOXI-Borderlands es un videojuego de disparos en primera persona de ciencia ficción con elementos de los videojuegos de rol desarrollado por Gearbox Software para las plataformas Microsoft Windows, Xbox 360 y PlayStation 3. (Wikipedia).";
				fwrite($archivo, $nueva_descripcion) or die("No se pudo escribir en el archivo");
				fclose($archivo); 
			}
  	?>          