
		<?php
			class Cuentas
			{
				private $codCliente;
				private $numeroCuenta;
				private $nombre;
				private $apellidos;
				private $saldo;
					
				public function __construct($codCliente, $numeroCuenta, $nombre, $apellidos, $saldo)
				{
					$this->codCliente = $codCliente;          
					$this->numeroCuenta = $numeroCuenta; 
					$this->nombre = $nombre; 
					$this->apellidos = $apellidos; 
					$this->saldo = $saldo; 
				}

				public function getCodCliente()
				{
					return $this->codCliente;          
				}
				public function getNumeroCuenta()
				{
					return $this->numeroCuenta;          
				}
				public function getNombre()
				{
					return $this->nombre;          
				}

				public function getApellidos()
				{
					return $this->apellidos;          
				}
				public function getSaldo()
				{
					return $this->saldo;          
				}
				public function ingresarDinero($cantidad)
				{
					$this->saldo = $this->saldo + $cantidad;					        
				}
				
				public function sacarDinero($cantidad)
				{
					$this->saldo = $this->saldo - $cantidad;          
				}
				public function consultarSaldo()
				{
					return $this->saldo;          
				}
			
			}
					
		?>		
			
		