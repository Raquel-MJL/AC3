<?php

    use PHPUnit\Framework\TestCase;

    class cuentas_test extends TestCase
    {
        public function testTiposDatos()
        {
            $cuenta1 = new Cuentas("ADC445W", 1234567890, "Pepe","Pérez Díaz",0.0);

            $this->assertIsString($cuenta1->getCodCliente());
			$this->assertIsInt($cuenta1->getNumeroCuenta());
			$this->assertIsString($cuenta1->getNombre());
			$this->assertIsString($cuenta1->getApellidos());
			$this->assertIsFloat($cuenta1->getSaldo());
        }

        public function testDatosNoNulos()
        {
			$cuenta1 = new Cuentas("ADC445W", 1234567890, "Pepe","Pérez Díaz",0.0);

            $this->assertNotNull($cuenta1->getCodCliente());
			$this->assertNotNull($cuenta1->getNumeroCuenta());
			$this->assertNotNull($cuenta1->getNombre());
			$this->assertNotNull($cuenta1->getApellidos());
			$this->assertNotNull($cuenta1->getSaldo());

        }

    }

?>