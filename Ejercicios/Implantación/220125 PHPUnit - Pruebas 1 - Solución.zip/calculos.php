<?php

/* Funciones aritméticas básicas.*/

   function Suma($n1, $n2): mixed
    {
        return $n1 + $n2;
    }
    function Resta($n1, $n2)
    {
        return $n1 - $n2;
    }
    function Producto($n1, $n2)
    {
        return $n1 * $n2;
    }
    function Division($n1, $n2)
    {
        return $n1 / $n2;
    }
      
	$suma = Suma(34,12);
    $resta = Resta(15,9);
    $producto = Producto(5,3);
    $division = Division(12,2);

	echo "<p> Suma: " .$suma. "</p>";
    echo "<p> Resta: " .$resta. "</p>";
    echo "<p> Producto: " .$producto. "</p>";
    echo "<p> Division: " .$division. "</p>";
   
// Ejecución en una terminal:
   // phpunit --bootstrap calculos.php calculos_test.php

?>