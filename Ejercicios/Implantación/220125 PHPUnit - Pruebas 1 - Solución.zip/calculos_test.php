<?php
use PHPUnit\Framework\TestCase;

    class calculos_test extends TestCase
    {
        
        public function test_suma()
        {
            $this->assertEquals(90,Suma(40,50));       
        }
        public function test_resta()
        {
           $this->assertEquals(5,Resta(75,70));       
        }
        public function test_producto()
        {
            $this->assertEquals(6,Producto(2,3));       
        }
        public function test_division()
        {
            $this->assertEquals(10,Division(30,3));       
        }

        public function test_todas()
        {
            $this->assertEquals(20,Suma(10,10)); 
            $this->assertEquals(5,Resta(75,70)); 
            $this->assertEquals(6,Producto(2,3)); 
            $this->assertEquals(10,Division(30,3));    
        }

     }
?>